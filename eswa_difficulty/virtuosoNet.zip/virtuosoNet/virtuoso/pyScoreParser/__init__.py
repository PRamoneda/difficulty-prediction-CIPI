# Copyright 2018.
# Dasaem Jeong from Music and Audio Computing Lab, KAIST http://mac.kaist.ac.kr/
# All Rights Reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0

# import .xml_midi_matching
# from .xml_midi_matching import *
# from .xml_matching import *
# from .midi_utils import midi_utils
# from .musicxml_parser import mxp